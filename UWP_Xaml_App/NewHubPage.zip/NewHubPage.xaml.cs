﻿using AzureConnections;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace UWPXamlApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class NewHub : Page
    {
        public static class Cons
        {
            public static string ResourceGroupName { get { return MyConnections.AzureGroup; } set { MyConnections.AzureGroup = value; } }
            public static string IoTHubName { get { return MyConnections.IoTHubName; } set { MyConnections.IoTHubName = value; } }
            public static string DeviceId { get { return MyConnections.DeviceId; } set { MyConnections.DeviceId = value; } }

            public static string IoTHubConnectionString { get { return MyConnections.IoTHubConnectionString; } set { MyConnections.IoTHubConnectionString = value; } }

            public static string DeviceConnectionString { get { return MyConnections.DeviceConnectionString; } set { MyConnections.DeviceConnectionString = value; } }

            public static string EventHubsConnectionString { get { return MyConnections.EventHubsConnectionString; } set { MyConnections.EventHubsConnectionString = value; } }

            public static string EventHubsCompatibleEndpoint { get { return MyConnections.EventHubsCompatibleEndpoint; } set { MyConnections.EventHubsCompatibleEndpoint = value; } }

            public static string EventHubsCompatiblePath { get { return MyConnections.EventHubsCompatiblePath; } set { MyConnections.EventHubsCompatiblePath = value; } }

            public static string IotHubKeyName { get { return MyConnections.IotHubKeyName; } set { MyConnections.IotHubKeyName = value; } }

            public static string IoTHubLocation { get { return MyConnections.IoTHubLocation; } set { MyConnections.IoTHubLocation = value; } }

            public static string SKU { get { return MyConnections.SKU; } set { MyConnections.SKU = value; } }

        }

        public string ResourceGroupName { get; set; } = "GroupName";
        public string IoTHubName { get; set; } = "HubName";

        public string DeviceName { get; set; }

        public string location { get => location1; set { location1 = value; } } 
        public string sku { get => sku1; set { sku1 = value; } }// Update(); }  }

        public  string LoginCode
        {
            get { return "az login"; }
        }
        public  string NewGroupCode
        {
            get { return string.Format("az group create --name {0} --location centralus", ResourceGroupName, location); }
        }

        public  string NewHubCode
        {

            get { return string.Format("az iot hub create --name {0}    --resource-group {1} --sku {2}", IoTHubName, ResourceGroupName, sku); }
        }

        public string DeleteHubCode
        {
            get { return string.Format("az iot hub delete --name {0}   --resource-group {1}",IoTHubName, ResourceGroupName); }
        }

        public string DeleteGroupCode
        {
            get { return string.Format("az group delete --name {0}", ResourceGroupName); }
        }

        public string iotownerconstring {
            get { return string.Format("az iot hub show-connection-string --name {0} --policy-name iothubowner --key primary  --resource-group {1}", IoTHubName, ResourceGroupName); }
        }

        public string serviceconstring
        {
            get { return string.Format("az iot hub show-connection-string --name {0} --policy-name service --key primary  --resource-group {1}", IoTHubName, ResourceGroupName); }
        }

        public NewHub()
        {


            this.InitializeComponent();
            //if (this.Frame.CanGoBack)
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Visible;
            //else
            //SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Collapsed;
            //NG.ValueChanged = ValueChangedGroup;
            //NH.ValueChanged = ValueChangedHub;
        }

        public void Update()
        {
            Task.Run(async () =>
            {
                await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
                {
                    //if (!string.IsNullOrEmpty(Cons.ResourceGroupName))
                    //    NG.Text = Cons.ResourceGroupName;
                    //if (!string.IsNullOrEmpty(Cons.IoTHubName))
                    //    NH.Text = Cons.IoTHubName;
                    //if (!string.IsNullOrEmpty(Cons.DeviceId))
                    //    ND.Text = Cons.DeviceId;
                    //if (!string.IsNullOrEmpty(Cons.IoTHubConnectionString))
                    //    NCS1.Text = Cons.IoTHubConnectionString;
                    //if (!string.IsNullOrEmpty(Cons.DeviceConnectionString))
                    //    NCS2.Text = Cons.DeviceConnectionString;
                    ResourceGroupName = NG.Text;
                    IoTHubName = NH.Text;

                    Login.Code = LoginCode;
                    NGCode.Code = NewGroupCode;
                    NHCode.Code = NewHubCode;
                    DelHub.Code = DeleteHubCode;
                    DelGrp.Code = DeleteGroupCode;
                    HubOwnerConString.Code = iotownerconstring;
                    HubServoceConString.Code = serviceconstring;
                    //Multicom.Code = "To create a new Device connection to the Hub you need the iothubowner ConnectionString."
                    //+"To run the DeviceStreaming functionality you only need the Service ConnectionString but can use the iothubowner ConnectionString. " 
                    //+"To create a new Device, return and choose [ADD New IoT Hub Device ...] from the Service menu.";

                });
            });
        }

        //public void ValueChangedGroup(string val)
        //{
        //    ResourceGroupName = val;
        //    Update();         
        //}

        //public void ValueChangedHub(string val)
        //{
        //    IoTHubName = val;
        //    Update();
        //}

        string msg = "Hello Hub";
        private string sku1 = "F1";
        private string location1 = "centralus";

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var dataPackage = new DataPackage();
            dataPackage.SetText(msg);
            Windows.ApplicationModel.DataTransfer.Clipboard.SetContent(dataPackage);
        }


        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            h1.SubRegion = this.GettingStarted;
            h2.SubRegion = this.Info;
            h2.IsExpanded = true;
            h3.SubRegion = this.ConnectingAndGroup;
            h4.SubRegion = this.NewHubRegion;
            h5.SubRegion = this.NewHDevice;
            h6.SubRegion = this.Cleanup;
            h7.SubRegion = this.Misc;
            if (!string.IsNullOrEmpty(Cons.ResourceGroupName))
                NG.Text = Cons.ResourceGroupName;
            if (!string.IsNullOrEmpty(Cons.IoTHubName))
                NH.Text = Cons.IoTHubName;
            if (!string.IsNullOrEmpty(Cons.DeviceId))
                ND.Text = Cons.DeviceId;
            if (!string.IsNullOrEmpty(Cons.IoTHubConnectionString))
                NCS1.Text = Cons.IoTHubConnectionString;
            if (!string.IsNullOrEmpty(Cons.DeviceConnectionString))
                NCS2.Text = Cons.DeviceConnectionString;
            if (!string.IsNullOrEmpty(Cons.SKU))
            {
                if (Cons.SKU== "F1")
                    {
                    rbF1.IsChecked = true;
                }
                else
                    rbS1.IsChecked = true;
            }
            else
                rbS1.IsChecked = true;


            Update();
            NewHubElement.ValueChanged = ValueChangedD;
        }

        public void ValueChangedD(string propertyName)
        {
            System.Diagnostics.Debug.WriteLine(propertyName);
            switch (propertyName.ToLower())
            {
                case "group":
                    ResourceGroupName = NG.Text;
                    NGCode.Code = NewGroupCode;
                    DelGrp.Code = DeleteGroupCode;
                    break;
                case "hub":
                    IoTHubName = NH.Text;
                    NHCode.Code = NewHubCode;
                    DelHub.Code = DeleteHubCode;
                    HubOwnerConString.Code = iotownerconstring;
                    HubServoceConString.Code = serviceconstring;
                    break;
                case "device":
                    DeviceName = ND.Text;
                    break;
            }
        }

        private void RbF1_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is Control)
            {
                if (((Control)sender).Tag != null)
                {
                        string tag = (string)((Control)sender).Tag;
                    if (!string.IsNullOrEmpty(tag))
                    {
                        switch (tag)
                        {
                            case "0":
                                sku1 = "F1";
                                break;
                            case "1":
                                sku1 = "S1";
                                break;
                        }
                        Update();
                    }
                }
            }
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var cb = Windows.ApplicationModel.DataTransfer.Clipboard.GetContent();
            string HubconString = await cb.GetTextAsync();
            if (!string.IsNullOrEmpty(HubconString))
            {
                NCS1.Text = HubconString;
                NCS1.Update();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            AzureConnections.MyConnections.AddDeviceAsync(NCS1.Text, ND.Text);
            if (!string.IsNullOrEmpty(Cons.DeviceConnectionString))
            {
                NCS2.Text = Cons.DeviceConnectionString;
                NCS2.Update();
            }
        }

    


        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            AzureConnections.MyConnections.GetDeviceCSAsync(NCS1.Text,ND.Text);
            if (!string.IsNullOrEmpty(Cons.DeviceConnectionString))
            {
                NCS2.Text = Cons.DeviceConnectionString;
                NCS2.Update();
            }
        }

        private async  void Button_Click_4(object sender, RoutedEventArgs e)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
            if (string.IsNullOrEmpty(NCS1.Text))
                return;
            if (string.IsNullOrEmpty(ND.Text))
                return;
            string cshub = NCS1.Text;
            string[] parts = cshub.Split(new char[] { '=' });
            if (parts.Length > 1)
            {
                if (!string.IsNullOrEmpty(parts[1]))
                {
                    parts = parts[1].Split(new char[] { '.' });
                    if (parts.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(parts[0]))
                        {
                            NH.Text = parts[0];
                            string devid = ND.Text;
                                NH.Update();
                                Update();
                            }
                        }
                    }
                }
            });
        }
    }
}
